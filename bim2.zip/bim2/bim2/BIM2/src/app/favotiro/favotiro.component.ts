import { Component } from '@angular/core';

@Component({
  selector: 'app-favotiro',
  templateUrl: './favotiro.component.html',
  styleUrl: './favotiro.component.css'
})
export class FavotiroComponent {

}
