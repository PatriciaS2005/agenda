import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FavotiroComponent } from './favotiro.component';

describe('FavotiroComponent', () => {
  let component: FavotiroComponent;
  let fixture: ComponentFixture<FavotiroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FavotiroComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FavotiroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
